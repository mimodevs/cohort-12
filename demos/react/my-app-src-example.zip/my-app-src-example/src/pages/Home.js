import React from 'react';

function Home () {
  return (
    <main>
      <h1>HOME PAGE</h1>
      <div>This is our home page.</div>
    </main>
  );
}

export default Home;
