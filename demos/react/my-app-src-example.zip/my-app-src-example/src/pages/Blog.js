import React from 'react';

function Blog () {
  return (
    <main>
      <h1>Blog Articles</h1>
      <div>This is blog page.</div>
    </main>
  );
}

export default Blog;
