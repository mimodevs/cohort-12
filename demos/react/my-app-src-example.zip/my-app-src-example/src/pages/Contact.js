
import React from 'react';

function Contact () {
  return (
    <main>
      <h1>Contact</h1>
      <div>Contact Page</div>
    </main>
  );
}

export default Contact;
