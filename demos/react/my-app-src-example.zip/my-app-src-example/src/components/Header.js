import React from 'react';

function Header () {
  return (
    <header>
      This is Header
    </header>
  );
}

export default Header;
